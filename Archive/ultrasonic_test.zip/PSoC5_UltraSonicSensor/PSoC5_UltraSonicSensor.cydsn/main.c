/* ========================================
 *
 * Copyright Electric Spectre, 2017
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF Electric Spectre.
 *
 * ========================================*/
#include "project.h"

volatile int count;

int main(void)
{
    CyDelay(500);
    Trigr_Write(0);
    CyDelay(500);
    for(;;)
    {
        count = 0;
        Trigr_Write(1);
        CyDelayUs(10);
        Trigr_Write(0);
        while(Echo_Read() == 0)
        {
        }
        while(Echo_Read() == 1)
        {
            count++; 
        }
        if(count <= 3000)
        {
            LED_Write(1);   
        }
        if(count > 4500)
        {
            LED_Write(0);
        }
        CyDelay(30);
    }
}

/* [] END OF FILE */
